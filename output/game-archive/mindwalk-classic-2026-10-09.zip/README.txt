Mindwalk Classic snapshot, October 9, 2026.
Original 6x6 maze, three thoughts, eight-second preview.
These source files belong to the Penn Grey Matters Next.js project.
The playable preserved version lives at /mindwalk/classic.
